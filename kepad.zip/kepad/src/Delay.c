/*
 * Delay.c
 *
 *  Created on: Jan 2, 2020
 *      Author: dbouba
 */

#include "Delay.h"

static uint32_t SysTickCounter = 0;


void SysTick_Init()
{
	SysTick_Config(SystemCoreClock / 1000);
}


void SysTick_Increment(void)
{
  ++SysTickCounter;
}

uint32_t SysTick_CurrentValue(void)
{
  return(SysTickCounter);
}


void Delay_ms(uint32_t wait_time_ms)
{
  uint32_t StartTick = SysTickCounter;

  while((SysTickCounter - StartTick) < wait_time_ms);

 }

