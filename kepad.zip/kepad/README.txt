To be able to run SWV on the STM32F429I-Discovery board, the solder bridge SB9 
on the backside of the board must be soldered. Please refer to the 
STM32F429I-Discovery User Manual for more information.