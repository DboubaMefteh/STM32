/*
 * Delay.h
 *
 *  Created on: Jan 2, 2020
 *      Author: dbouba
 */

#ifndef DELAY_H_
#define DELAY_H_

#include "stm32f4xx.h"

void SysTick_Init(void);

void SysTick_Increment(void);
uint32_t SysTick_CurrentValue(void);

void Delay_ms(uint32_t wait_time_ms);
//void Delay_S(uint32_t wait_time_S);

#endif /* DELAY_H_ */
